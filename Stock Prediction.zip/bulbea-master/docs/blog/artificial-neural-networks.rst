Artificial Neural Networks
==========================

	*"All models are wrong, but some are useful."* - George E. P. Box

Recurrent Neural Networks
+++++++++++++++++++++++++

A vanilla Recurrent Neural Network (hereby, RNN) is a kind of an Artificial Neural Network that considers a scenario - *at which time-step did you feed the input?*