Vizualizing the Market
======================