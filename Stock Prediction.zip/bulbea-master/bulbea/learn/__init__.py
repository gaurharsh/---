# module - bulbea.learn
from bulbea.learn.sentiment import sentiment
