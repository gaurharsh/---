# imports - compatibility imports
from __future__ import absolute_import

# imports - third-party packages
import textblob

# module imports
from bulbea.learn.sentiment.twitter import Twitter

def sentiment(share):
    pass
