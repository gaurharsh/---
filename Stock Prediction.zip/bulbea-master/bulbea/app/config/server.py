# imports - compatibility packages
from __future__ import absolute_import

# module imports
from bulbea.app.config import BaseConfig

class ServerConfig(BaseConfig):
    pass
