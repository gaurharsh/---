#!/usr/bin/env python

# imports - compatibility imports
from __future__ import absolute_import

# imports - standard imports
import sys

# imports - module imports
from bulbea.cli import main

if __name__ == '__main__':
    sys.exit(main())
