TYPE_ERROR_STRING = 'Expected {expected_type_name}, got {recieved_type_name} instead.'
