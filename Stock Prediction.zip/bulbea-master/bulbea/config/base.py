from six import with_metaclass

from abc import ABCMeta

class BaseConfig(with_metaclass(ABCMeta)):
    pass
