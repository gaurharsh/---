from six import with_metaclass

from abc import ABCMeta

class Entity(with_metaclass(ABCMeta)):
    pass
